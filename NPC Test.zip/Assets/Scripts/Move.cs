﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    public float speed;

    private Rigidbody _myRigidbody;
    // Start is called before the first frame update
    void Start()
    {
        _myRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow))
            _myRigidbody.velocity = new Vector3(0f, _myRigidbody.velocity.y, speed);
        if (Input.GetKeyDown(KeyCode.DownArrow))
            _myRigidbody.velocity = new Vector3(0f, _myRigidbody.velocity.y, -speed);
        if (Input.GetKeyDown(KeyCode.LeftArrow))
            _myRigidbody.velocity = new Vector3(-speed, _myRigidbody.velocity.y, 0f);
        if (Input.GetKeyDown(KeyCode.RightArrow))
            _myRigidbody.velocity = new Vector3(speed, _myRigidbody.velocity.y, 0f);

        if (Input.GetKeyUp(KeyCode.UpArrow))
            _myRigidbody.velocity = new Vector3(0f, _myRigidbody.velocity.y, 0f);
        if (Input.GetKeyUp(KeyCode.DownArrow))
            _myRigidbody.velocity = new Vector3(0f, _myRigidbody.velocity.y, 0f);
        if (Input.GetKeyUp(KeyCode.LeftArrow))
            _myRigidbody.velocity = new Vector3(0f, _myRigidbody.velocity.y, 0f);
        if (Input.GetKeyUp(KeyCode.RightArrow))
            _myRigidbody.velocity = new Vector3(0f, _myRigidbody.velocity.y, 0f);
    }
}