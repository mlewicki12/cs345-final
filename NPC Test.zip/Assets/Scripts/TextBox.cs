﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextBox : MonoBehaviour
{
    public GameObject Canvas;

    private void OnTriggerStay(Collider other)
    {
        Canvas.GetComponent<Canvas>().enabled = true;
    }
    private void OnTriggerExit(Collider other)
    {
        Canvas.GetComponent<Canvas>().enabled = false;
    }
}
